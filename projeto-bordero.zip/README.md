# Borderô Semanal — Apresentação

Este projeto é um exemplo de sistema de apresentação de Borderô Semanal em React/Tailwind.
Inclui instruções para rodar localmente e hospedar online.
