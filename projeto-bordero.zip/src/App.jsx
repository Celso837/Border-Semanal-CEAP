// Código React/Tailwind do sistema de Borderô aqui
